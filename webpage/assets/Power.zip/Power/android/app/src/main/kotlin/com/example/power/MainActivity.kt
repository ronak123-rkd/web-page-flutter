package com.example.power

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
