import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import '../../homepage.dart';
import 'filtercharging.dart';



class ChargingHistory extends StatelessWidget {
  const ChargingHistory({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      body: Padding(
        padding: EdgeInsets.only(top: 6.9.h),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(left: 7.w),
              child: Row(
                children: [
                  GestureDetector(
                    child: Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                      size: 4.h,
                    ),
                    onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context) =>   HomePage()),
                     );}
                  ),
                  SizedBox(
                    width: 13.w,
                  ),
                  Text("Charging History", style: TextStyle(fontSize: 18.sp,  color: Colors.white),),
                  SizedBox(
                    width: 13.w,
                  ),
                  GestureDetector(
                      child: Icon(
                        Icons.filter_list,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context) =>   Filter()),
                      );}
                  ),

                ],
              ),
            ),
            SizedBox(height:3.h ),
            Expanded(
              child: Container(
                height: MediaQuery.of(context).size.height,
                width:  MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),
                  ),
                  color: Colors.white,
                ),
                child: Column(
                  children: [

                    Padding(
                      padding:  EdgeInsets.only(top: 25.h),
                      child: Image.asset("assets/no.jpeg",width: 55.w,),
                    ),
                    SizedBox(
                      height: 2.h,
                    ),
                    Text("No Charging History!",style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w500,color: Colors.black)),
                    SizedBox(
                      height: 2.h,
                    ),
                    Container(
                        height: 6.h,
                        width: 90.w,
                        child: Text("Looks Like you don't have any charging history yet",
                            textAlign: TextAlign.center,maxLines: 2,style: TextStyle(fontSize: 13.sp,color: Colors.black))
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}
