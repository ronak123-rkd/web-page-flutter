import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import 'addvehicleinfo.dart';

class Vehicles extends StatelessWidget {
  const Vehicles({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      appBar: AppBar(
        backgroundColor: const Color(0xff4973f5),
        elevation: 0.0,
        centerTitle: true,
        title: Text("My Vehicles",style: TextStyle(fontWeight:FontWeight.normal, fontSize: 18.sp),),
      ),
      body: Padding(
        padding:  EdgeInsets.only(top: 3.h),
        child: Container(
          height: 100.h,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(35), topRight: Radius.circular(35),)
          ),
          child:   Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding:  EdgeInsets.only(bottom: 10.5.h,left: 5.w),
                child: FlatButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => AddVehicle()),);
                    },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.h)),
                  child:  Text("Add",style: TextStyle(fontWeight:FontWeight.w500, fontSize: 12.sp,color: Colors.white)),
                  color: Colors.blue,
                  height: 7.5.h,
                  minWidth: 74.w,
                ),
              ),
            ],
          ) ,
        ),
      ),
    );

  }
}

