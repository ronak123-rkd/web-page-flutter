import 'package:flutter/material.dart';
import 'package:power/profilescreen/vehiclesscreen/vehicleadd.dart';
import 'package:sizer/sizer.dart';

class AddVehicle extends StatefulWidget {
   AddVehicle({Key? key}) : super(key: key);

  @override
  State<AddVehicle> createState() => _AddVehicleState();
}

class _AddVehicleState extends State<AddVehicle> {

  Map<String, String> statemodel = {
    "E-Tigor": "Tata Motors",
    "Nexon Ev": "Tata Motors",
    "Tigor EV Ziptron ": "Tata Motors",
    "E-Verito": "Mahindra",
    "e20 Plus 8": "Mahindra",
    "Kona": "Hyundai",
    "ZS EV": "Mg Motors",
    "I-PACE": "Jaguar",
  };

  List<String> car = ['Tata Motors', 'Mahindra', 'Hyundai', 'Mg Motors', 'Jaguar'];
  List<String> model = [];

  var currentval= null;
  var currentval1= null;



  @override
  Widget build(BuildContext context) {
    return WillPopScope(onWillPop: () async => true,
      child: Scaffold(
        backgroundColor: const Color(0xff4973f5),
          body:  Padding(
            padding: EdgeInsets.only(top: 3.9.h),
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 3.1.h, right: 9.5.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "Add Vehicle Info"  ,
                        style: TextStyle(
                          fontSize: 18.5.sp,
                          color: Colors.white,),
                      ),
                      SizedBox(
                        width: 12.5.w,
                      ),
                      GestureDetector(
                          child: Icon(
                            Icons.close_rounded,
                            color: Colors.white,
                            size: 4.5.h,
                          ),
                          onTap: () {
                            Navigator.pop(context);
                          }),
                    ],
                  ),
                ),
                SizedBox(
                  height: 8.h,
                ),
                Expanded(
                  child: Container(
                    height: 100.h,
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(35),
                        topRight: Radius.circular(35),
                      ),
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding:  EdgeInsets.only(top: 9.5.h,left: 10.w,right: 10.w),
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:   EdgeInsets.only(left: 2.h,),
                              child: Text("Make*", style: TextStyle(
                                fontSize: 11.sp,
                                color: Colors.grey,),),
                            ),
                            DropdownButton<String>(
                              value: currentval,
                              icon: const Icon(Icons.keyboard_arrow_down_outlined,color: Colors.blue, ),
                              elevation: 16,
                              isExpanded: true,
                              style:  TextStyle(color: Colors.black, fontSize: 14.sp),

                              onChanged: (String? newValue) {
                                setState(() {
                                  currentval = newValue!;
                                  currentval1 = null;
                                  model.clear();
                                  statemodel.forEach((k,v){
                                    print(k);
                                    if(currentval==v){
                                      model.add(k);
                                    }
                                  });
                                });
                              },
                              items: <String> [ 'Tata Motors', 'Mahindra', 'Hyundai', 'Mg Motors', 'Jaguar'] .map <DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                            SizedBox(
                              height: 7.h,
                            ),
                            DropdownButton<String>(
                              hint: Text("Model*", style: TextStyle(fontSize: 14.sp, color: Colors.grey),),
                              value: currentval1,
                              icon: const Icon(Icons.keyboard_arrow_down_outlined,color: Colors.blue, ),
                              elevation: 16,
                              isExpanded: true,
                              style:  TextStyle(color: Colors.black, fontSize: 14.sp),

                              onChanged: (String? newValue) {
                                setState(() {
                                  currentval1 = newValue!;
                                });
                                print(newValue);
                              },
                              items: <String> [ 'E-Tigor', 'Nexon Ev', 'Tigor EV Ziptron ', 'E-Verito', 'e20 Plus 8', 'Kona', 'ZS EV', 'I-PACE'] !=  null ?
                                 model.map <DropdownMenuItem<String>>((model) {
                                return DropdownMenuItem<String>(
                                  value: model,
                                  child: Text(model),
                                );
                              }).toList() : [],
                            ),
                            SizedBox(
                              height: 4.h,
                            ),
                            TextFormField(
                              cursorHeight: 5.h,
                              cursorColor: Colors.grey.withOpacity(0.1),
                              decoration: InputDecoration(
                                labelText: "Vehicle Registration Number",
                                labelStyle: TextStyle(color: Colors.grey,fontSize: 15.sp),
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                                ),
                                focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                                ),
                                suffixIcon: InkWell(
                                  onTap: () {
                                    setState(() {

                                    });
                                  },
                                  child:  Icon(Icons.info_outline,color: Colors.blue.withOpacity(0.5),),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 5.5.h ,
                            ),
                            TextFormField(
                              cursorHeight: 5.h,
                              cursorColor: Colors.grey.withOpacity(0.1),
                              decoration: InputDecoration(
                                labelText: "VIN",
                                labelStyle: TextStyle(color: Colors.grey,fontSize: 15.sp),
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                                ),
                                focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                                ),
                                suffixIcon: InkWell(
                                  onTap: () {
                                    setState(() {

                                    });
                                  },
                                  child:  Icon(Icons.info_outline,color: Colors.blue.withOpacity(0.5),),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 4.3.h,
                            ),
                            FlatButton(
                              onPressed: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Add()),);
                              },
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(2.h)),
                              child:  Text("Add",style: TextStyle(fontWeight:FontWeight.w500, fontSize: 12.sp,color: Colors.white)),
                              color: Colors.blue,
                              height: 7.5.h,
                              minWidth: 80.w,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
      ),
    );
  }
}
