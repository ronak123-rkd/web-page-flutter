import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:power/homepage.dart';
import 'package:sizer/sizer.dart';
import 'addvehicleinfo.dart';
import 'editvehicleinfo.dart';

class Add extends StatefulWidget {
  const Add({Key? key}) : super(key: key);

  @override
  State<Add> createState() => _AddState();
}

class _AddState extends State<Add> {

  List<String> text5 = [
    "Tata Motors",
    "Hyundai"
  ];

  List<String> text8 = [
    "E-Tigor",
    "kona"
  ];

  List<String> image1 = [
    "https://images.livemint.com/img/2021/07/15/1600x900/Tata1_1626328428541_1626328436555.jpg",
    "https://images.livemint.com/img/2021/07/15/1600x900/Tata1_1626328428541_1626328436555.jpg"
  ];


  List<String> image2 = [
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png",
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png"
  ];

  List<String> text6 = [
    "Bharat DC001 GB/T",
     "CCS-2"
  ];

  List<String> image3 = [
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png",
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png"
  ];

  List<String> text7 = [
    "Bharat AC001",
    "AC Type-2",

  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      appBar: AppBar(
        leading: BackButton(
          onPressed: (){
            Navigator.pushReplacementNamed(context,'/');
          },
        ),
        backgroundColor: const Color(0xff4973f5),
        elevation: 0.0,
        centerTitle: true,
        title: Text("My Vehicles",style: TextStyle(fontWeight:FontWeight.normal, fontSize: 18.sp),),
      ),
      body: Padding(
        padding:  EdgeInsets.only(top: 3.h),
        child: Container(
          height: 100.h,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(35), topRight: Radius.circular(35),)
          ),


          child: Column(
            children: [
              Expanded(
                child: SizedBox(
                  height: 84.h,
                  width: 90.w,
                  child: Padding(
                    padding:  EdgeInsets.only(top: 0.9.h),
                    child: ListView.builder(

                        itemCount: text5.length,

                        itemBuilder: (context,index){


                      return  Padding(
                        padding:  EdgeInsets.only(top:6.h),
                        child: Container(
                          height: 54.h,
                          width: 91.w,
                          decoration:  BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey.withOpacity(0.5), style: BorderStyle.solid, width: 1.0,) ,
                          ),
                          child: Column(
                            children: [
                              Padding(
                                padding:  EdgeInsets.only(top: 1.h, ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: [
                                    Row(
                                      children: [
                                        Text(text5[index],style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.bold,color: Colors.black),),
                                        SizedBox(
                                          width: 2.w,
                                        ),
                                        Text(text8[index],style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.bold,color: Colors.black),),
                                      ],
                                    ),

                                    SizedBox(
                                      width: 2.w,
                                    ),
                                    Icon(Icons.delete_outline,color: Colors.red, size: 3.5.h,),
                                    InkWell(
                                        onTap: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => EditVehicle()),);
                                        },
                                        child: Icon(Icons.edit,color: Colors.blue, size: 3.5.h,)),
                                  ],
                                ),

                              ),
                              Image.network(image1[index],height: 30.h,width: 60.w ,),
                              SizedBox(
                                height: 1.h,
                              ),
                              Container(
                                height: 18.18.h,
                                width: MediaQuery.of(context).size.width,
                                decoration:  BoxDecoration(
                                  color: Colors.grey.withOpacity(0.1),
                                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10), bottomRight: Radius.circular(10),),
                                ),
                                child: Padding(
                                  padding:  EdgeInsets.only(left: 3.w),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    // crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text("Connector",style: TextStyle(fontSize: 11.sp,color: Colors.black.withOpacity(0.4),fontWeight: FontWeight.w500),),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              Image.network(
                                                image2[index],height: 3.5.h,width: 11.w,
                                              ),


                                              Text(text6[index],style: TextStyle(fontSize: 12.sp,color: Colors.black,fontWeight: FontWeight.bold),),
                                            ],
                                          ),

                                          Padding(
                                            padding:  EdgeInsets.only(right: 5.w),
                                            child: Container(
                                              child: Center(
                                                  child: Text(
                                                    "DC",
                                                    style: TextStyle(
                                                        color: Colors.black.withOpacity(0.5), fontSize: 12.sp),
                                                  )),
                                              height:3.h,
                                              width: 10.w,
                                              decoration: BoxDecoration(
                                                  border: Border.all(color: Colors.black.withOpacity(0.5)),
                                                  color:  Colors.white,
                                                  borderRadius: BorderRadius.circular(30)),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(


                                            children: [
                                              Image.network(
                                               image3[index],height: 3.5.h,width: 11.w,
                                              ),

                                              Text(text7[index],style: TextStyle(fontSize: 12.sp,color: Colors.black,fontWeight: FontWeight.bold),),

                                            ],
                                          ),
                                          Padding(
                                            padding:  EdgeInsets.only(right: 5.w),
                                            child: Container(
                                              child: Center(
                                                  child: Text(
                                                    "AC",
                                                    style: TextStyle(
                                                        color: Colors.black.withOpacity(0.5), fontSize: 12.sp),
                                                  )),
                                              height:3.h,
                                              width: 10.w,
                                              decoration: BoxDecoration(
                                                  border: Border.all(color: Colors.black.withOpacity(0.5)),
                                                  color:  Colors.white,
                                                  borderRadius: BorderRadius.circular(30)),
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),

                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ),
                ),
              )
            ],
          ),
        ),
      ),

      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 5.0,right: 2.2),
        child: FloatingActionButton(
          backgroundColor:  const Color(0xff4973f5),
          child: GestureDetector(

            child: const Icon(
              Icons.add,
              color: Colors.white,
              size: 25,
            ),
              onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context) =>   AddVehicle()),
              );}
          ),
          onPressed: () {},
        ),
      ),
    );
  }
}

