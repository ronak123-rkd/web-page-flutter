import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class FaqsPublicProfile extends StatelessWidget {
  static  double ?width;
  static  double ?height;

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: Text('Preferred Locations'),
      ),
      body: Container(
        decoration:BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(4.h))

        ),
        child: ListView.builder(
          itemCount: 10,
          itemBuilder: (context, index) => GridMenu(),
        ),
      ),
    );
  }
}

class GridMenu extends StatefulWidget {
  const GridMenu({Key? key}) : super(key: key);

  @override
  _GridMenuState createState() => _GridMenuState();
}

class _GridMenuState extends State<GridMenu> {
  bool _collapse = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: () => setState(() {
            _collapse = !_collapse;
          }),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                    child: Text(
                      'Category',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    )),
                Icon(_collapse
                    ? Icons.keyboard_arrow_up
                    : Icons.keyboard_arrow_down),
              ],
            ),
          ),
        ),
        AnimatedContainer(
          duration: Duration(milliseconds: 10),
          width: FaqsPublicProfile.width,
          height: _collapse ? FaqsPublicProfile.width : 0,
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
            ),
            itemCount: 10,
            itemBuilder: (context, index) => GestureDetector(
              onTap: () {
                /** choose item **/
              },
              child: Container(
                margin: EdgeInsets.all(16),
                color: Colors.green,
              ),
            ),
          ),
        ),
      ],
    );
  }
}