import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';






class Send extends StatefulWidget {
  const Send ({Key? key}) : super(key: key);

  @override
  _SendState createState() => _SendState();
}

class _SendState extends State<Send> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  bool _collapse = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue,
        appBar: AppBar(
          centerTitle: true,
          elevation: 0,
          title: Text('Send us an Email'),
        ),
        bottomNavigationBar: Container(
          color: Colors.white,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                    _collapse = !_collapse;
                  },
                  child: Container(
                    height:6.5.h,
                    width:80.w,
                    decoration: BoxDecoration(
                        color: _collapse==false? Colors.grey:Colors.blue,
                        borderRadius: BorderRadius.circular(10)
                    ),

                    child:Center(
                      child: Text(
                        'Send',
                        style: TextStyle(fontSize: 13.sp, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),


        body: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(4.h))

            ),
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 9.h, horizontal:9.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Have a different problem?',
                    textAlign: TextAlign.start,
                    style: TextStyle(fontWeight: FontWeight.bold),),
                  TextFormField(
                    cursorHeight: 5.h,
                    cursorColor: Colors.grey.withOpacity(0.1),
                    decoration: InputDecoration(
                      labelText: "Tell us more about it",
                      labelStyle: TextStyle(color: Colors.grey),
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                      ),
                    ),
                  ),






                ],




              ),
            )));








  }
}