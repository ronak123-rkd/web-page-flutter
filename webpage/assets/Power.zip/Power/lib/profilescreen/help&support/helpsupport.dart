import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'email.dart';
import 'faqspublic.dart';
import 'generalfaqs.dart';

class help_support extends StatefulWidget {
  const help_support({Key? key}) : super(key: key);

  @override
  _help_supportState createState() => _help_supportState();
}

class _help_supportState extends State<help_support> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  bool _collapse = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue,
        appBar: AppBar(
          centerTitle: true,
          elevation: 0,
          title: Text('Help & Support'),
        ),
        bottomNavigationBar: Container(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 6.5.h,
                  width: 40.w,
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(10)),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => Send()));
                    },
                    child: Center(
                      child: Text(
                        'Send us an Email',
                        style: TextStyle(fontSize: 12.sp, color: Colors.white),
                      ),
                    ),
                  ),
                ),
                Container(
                  height: 6.5.h,
                  width: 40.w,
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(10)),
                  child: InkWell(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              AlertDialog(
                                actionsOverflowButtonSpacing: 20,
                                actions: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Icon(Icons.call),
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context, 'Cancel'),
                                        child: const Text('Call 1800 833 2233'),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              AlertDialog(
                                actionsOverflowButtonSpacing: 20,
                                actions: [
                                  Center(
                                    child: TextButton(
                                      onPressed: () => Navigator.pop(
                                          context, 'help_support'),
                                      child: const Text('Cancel'),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          );
                        },
                      );
                    },
                    child: Center(
                      child: Text(
                        'Call Us',
                        style: TextStyle(fontSize: 12.sp, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        body: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(4.h))),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5.h, horizontal: 5.w),
                  child: Column(children: [
                    GestureDetector(
                      onTap: () => setState(() {
                        _collapse = !_collapse;
                      }),
                      child: Padding(
                        padding: EdgeInsets.only(left: 1.h),
                        child: InkWell(
                           onTap: () {
                               Navigator.push(context, MaterialPageRoute(builder: (context) => GeneralFaqs()));
                               },
                          child: Container(
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                Text('General FAQs'),
                                Icon(Icons.keyboard_arrow_right),
                                  ]
                              )
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 6.h,
                    ),
                    GestureDetector(
                      onTap: () => setState(() {
                        _collapse = !_collapse;
                      }),
                      child: Padding(
                        padding: EdgeInsets.only(left: 1.h),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => FaqsPublicProfile()));
                          },
                          child: Container(
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('FAQs for Public Profile'),
                                    Icon(Icons.keyboard_arrow_right),
                                  ])),
                        ),
                      ),
                    ),
                    /*Row(
                    children: [
                      Text('General FAQs ',
                          style:TextStyle(
                              fontSize:2.5.h)),*/
                  ]),
                  /*Row(
                    children: [
                      Text("FAQs for Public Profile",
                          style:TextStyle(
                              fontSize:2.5.h)),
                    ],
                  ),*/
                ),
              ],
            )));
  }
}
