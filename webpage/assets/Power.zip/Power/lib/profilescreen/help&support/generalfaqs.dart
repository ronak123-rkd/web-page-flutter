import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import 'faqspublic.dart';




class GeneralFaqs extends StatefulWidget {
    double ?width;
    double ?height;

  @override
  State<GeneralFaqs> createState() => _GeneralFaqsState();
}

class _GeneralFaqsState extends State<GeneralFaqs> {
  bool _collapse = false;

  List<String> text = [
    'Hello1',
    'Hello2',
    'Hello3',
    'Hello4',

  ];

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        backgroundColor: Colors.blue,
        appBar: AppBar(
          centerTitle: true,
          elevation: 0,
          title: Text('Preferred Locations'),
        ),
        body: Container(
          decoration:BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(4.h))

          ),
          child: ListView.builder(
            itemCount: text.length,
            itemBuilder: (context, index) =>  Column(
              children: [
                GestureDetector(
                  onTap: () => setState(() {
                    _collapse = !_collapse;
                  }),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Expanded(
                            child: Text(
                              text[index],
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            )),
                        Icon(_collapse
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down),
                      ],
                    ),
                  ),
                ),
                AnimatedContainer(
                  duration: Duration(milliseconds: 10),
                  width: FaqsPublicProfile.width,
                  height: _collapse ? FaqsPublicProfile.width : 0,
                  child: ListView.builder(
                    itemCount: 1,
                    itemBuilder: (context, index) => GestureDetector(
                      child: Container(
                          child:Text('gyehybgcdebchbbhjceftyctfgcvgtcfvgt')
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}