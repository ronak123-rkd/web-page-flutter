import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';




class Charge_card extends StatefulWidget {
  const Charge_card ({Key? key}) : super(key: key);

  @override
  _Charge_cardState createState() => _Charge_cardState();
}

class _Charge_cardState extends State<Charge_card> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: Text('EZ Charge Card'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(4.h))

        ),
        child: Column(
          mainAxisAlignment:MainAxisAlignment.center,
          children: [
            Padding(
              padding:  EdgeInsets.symmetric(vertical:5.h,horizontal: 5.w ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image(height: 90,width:90,image:AssetImage("assets/charg.png")),
                  Text('Coming Soon!',
                      style:TextStyle(fontWeight: FontWeight.bold,
                          fontSize:3.h)),
                ],
              ),
            ),
          ],
        ),
      ),
    );}
}