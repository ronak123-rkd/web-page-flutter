import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class TermConditions extends StatelessWidget {
  const TermConditions({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      body: Padding(
        padding: EdgeInsets.only(top: 6.8.h),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top:1.h, right: 4.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Terms & Conditions",
                    style: TextStyle(
                      fontSize: 19.sp,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    width: 13.w,
                  ),
                  GestureDetector(
                      child: Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      }),
                ],
              ),
            ),
            SizedBox(
              height: 3.2.h,
            ),
            Expanded(
              child: Container(
                height: 71.5.h,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),
                  ),
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
