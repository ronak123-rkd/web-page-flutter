import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class FilterUsage extends StatefulWidget {
  const FilterUsage({Key? key}) : super(key: key);

  @override
  State<FilterUsage> createState() => _Filter1State();
}

class _Filter1State extends State<FilterUsage> {

  int value = 0;

  List<String> text2 = [
    "Current Month",
    "February 2022",
    "January 2022",
    "December 2021",
    "November 2021",
    "October 2021",
    "September 2021",
    "August 2021",
    "July 2021",
    "June 2021",
    "May 2021",
    "April 2021",
    "March 2021",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.blue,
      body: Padding(
        padding: EdgeInsets.only(top: 6.8.h),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 1.h, right: 6.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Time filter",
                    style: TextStyle(
                        fontSize: 19.sp,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: 23.w,
                  ),
                  GestureDetector(
                      child: Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      }),
                ],
              ),
            ),
            SizedBox(
              height: 3.2.h,
            ),
            Expanded(
              child: Container(
                height: 71.5.h,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),
                  ),
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 7.7.h, left: 6.w),
                      child: Text(
                        "Show my usage for",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            fontSize: 12.sp),
                      ),
                    ),

                    Expanded(
                      child: ListView.builder(

                          itemCount: text2.length,

                          itemBuilder: (context, index) {

                            return Column(
                              children: [
                                Padding(
                                    padding:
                                    EdgeInsets.only( right: 3.w),
                                    child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            value = index;
                                          });

                                        },
                                        child: CustomRadioButton(text2[index],index))
                                ),
                                SizedBox(
                                  height: 1.7.h,
                                ),
                                Divider(
                                  color: Colors.black.withOpacity(0.2),
                                ),
                                SizedBox(
                                  height: 2.h,
                                ),
                              ],
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              height: 9.18.h,
              width: MediaQuery.of(context).size.width,
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FlatButton(
                    onPressed: () {},
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1.h)),
                    child:  Text("Clear",style: TextStyle(fontWeight:FontWeight.w500, fontSize: 12.sp,color: Colors.black)),
                    height: 7.h,
                    minWidth: 40.w,
                  ),
                  FlatButton(
                    onPressed: () {Navigator.pop(context);},
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1.h)),
                    child:  Text("Apply",style: TextStyle(fontWeight:FontWeight.w500, fontSize: 12.sp,color: Colors.white)),
                    color: Colors.blue,
                    height: 7.h,
                    minWidth: 40.w,
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget CustomRadioButton(String text,int index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding:  EdgeInsets.only(top: 1.h,left: 6.w),
          child: Text(
            text,
            style: (value == index) ?TextStyle(color:  Colors.black ,fontWeight: FontWeight.w800,fontSize: 12.sp):
            TextStyle(color:  Colors.black,fontSize: 12.sp),),
        ),
        Padding(
          padding:  EdgeInsets.only(right: 3.w),
          child: Container(
            height: 4.h,
            width: 4.h,
            decoration: BoxDecoration(
                border: (value == index) ?null:Border.all(color: Colors.grey,width: 0.2.w),
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(2.h)

            ),
            child: Container(
              height:(2.h),
              width:(2.h),
              decoration: BoxDecoration(
                  color: (value == index) ? Colors.lightGreen : Colors.white,
                  borderRadius: BorderRadius.circular(3.h)
              ),
              child: Icon(Icons.check,color: Colors.white,),
            ),
          ),
        ),
      ],
    );

  }
}