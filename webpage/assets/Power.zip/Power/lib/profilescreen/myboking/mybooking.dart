import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import 'filtterbooking.dart';
class MyBooking extends StatefulWidget {
  const MyBooking({Key? key}) : super(key: key);

  @override
  State<MyBooking> createState() => _MyBookingState();
}

class _MyBookingState extends State<MyBooking> {
  int index=0;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(onWillPop: () async => true,
      child: Scaffold(
        backgroundColor: const Color(0xff4973f5),
        body: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 7.h, right: 7.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "My Bookings"  ,
                    style: TextStyle(
                      fontSize: 18.sp,
                      color: Colors.white,),
                  ),
                  SizedBox(
                    width: 19.w,
                  ),
                  GestureDetector(
                      child: Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      }),
                ],
              ),
            ),
            SizedBox(
              height: 4.h,
            ),
            Expanded(
              child: Container(
                height: 85.h,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(top: 2.5.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment. spaceEvenly,
                        children: [
                          Column(
                            children: [
                              InkWell(
                                    onTap: () {
                                      setState(() {
                                        index=0;
                                      });

                                      },
                                  child: Container(
                                    height: 3.h,
                                    width: 35.w,
                                    child: Text("Upcoming Bookings",style: TextStyle(fontSize: 11.5.sp, fontWeight: FontWeight.bold,
                                      color: (index==0) ? Colors.black : Colors.black.withOpacity(0.5),),),
                                  )
                              ),
                              SizedBox(
                                height: 1.5.h,
                              ),
                              Container(
                                height: 0.6.h,
                                width: 34.w,
                                decoration:  BoxDecoration(
                                  color: (index==0) ? Colors.blue : null,
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(35),
                                    topRight: Radius.circular(35),),
                                ),

                              ),

                            ],
                          ),
                          Column(
                            children: [
                              InkWell(
                                  onTap: () {
                                    setState(() {
                                      index=1;
                                    });

                                  },
                                  child: Container(
                                    height: 3.h,
                                    width: 35.w,
                                    child: Text("Cancelled Bookings",style: TextStyle(fontSize: 11.5.sp, fontWeight: FontWeight.bold,
                                        color: (index==1) ? Colors.black : Colors.black.withOpacity(0.5)),),
                                  )
                              ),
                              SizedBox(
                                height: 1.5.h,
                              ),
                              Container(
                                height: 0.6.h,
                                width: 34.w,
                                decoration:  BoxDecoration(
                                  color: (index==1) ? Colors.blue : null,
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(35),
                                    topRight: Radius.circular(35),),
                                ),

                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    index==0?UB():CB(),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget UB() {
    return Padding(
      padding:  EdgeInsets.only(top: 18.h),
      child: Column(
        children: [
          Image.asset("assets/no.jpeg",width: 55.w,),
          SizedBox(
            height: 8.h,
          ),
          Text("No Bookings !",style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w500,color: Colors.black)),
          SizedBox(
            height: 4.h,
          ),
          Container(
              height: 6.h,
              width: 72.w,
              child: Text("Looks Like you haven't booked any slots yet", textAlign: TextAlign.center,style: TextStyle(fontSize: 12.sp,color: Colors.black.withOpacity(0.5)))),
        ]
      ),
    );
  }

  Widget CB() {
    return Padding(
      padding:  EdgeInsets.only(top:5.h),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                  height: 5.4.h,
                  width: 70.w,
                  child: Text("Showing cancelled bookings for next 7 days",maxLines:2, style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w500,color: Colors.black))
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => FiltterBooking()),
                  );
                },
                child: Container(
                    height: 5.4.h,
                    width:10.9.w,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.blue),
                        color:  Colors.white,
                        borderRadius: BorderRadius.circular(5)),
                    child: Icon(Icons.filter_list_outlined),
                    // child: Image.asset("assets/filtter1.jpg",height: 2.h,width: 15.w,)
                ),
              ),

            ],
          ),
          SizedBox(
            height: 17.h,
          ),
          Image.asset("assets/no.jpeg",width: 55.w,),
          SizedBox(
            height: 8.h,
          ),
          Text("No Bookings !",style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w500,color: Colors.black)),
          SizedBox(
            height: 4.h,
          ),
          Container(
            height: 6.h,
              width: 80.w,
              child: Text("Looks Like you don't have any cancelled bookings yet",
                  textAlign: TextAlign.center,maxLines: 2,style: TextStyle(fontSize: 12.sp,color: Colors.black.withOpacity(0.5)))
          ),
        ],
      ),
    );
  }



}
