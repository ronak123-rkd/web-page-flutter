import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class FiltterBooking extends StatefulWidget {
  const FiltterBooking({Key? key}) : super(key: key);

  @override
  State<FiltterBooking> createState() => _FiltterBookingState();
}

class _FiltterBookingState extends State<FiltterBooking> {

  int value = 0;

  List<String> text7 = [
    "Next 7 days",
    "Past 7 days",
    "Past 1 month",
    "Past 3 month",
    "Past 6 month"

  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      body: Padding(
        padding: EdgeInsets.only(top: 6.8.h),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 5.h, right: 6.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Time filter",
                    style: TextStyle(
                        fontSize: 19.sp,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: 23.w,
                  ),
                  GestureDetector(
                      child: Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      }),
                ],
              ),
            ),
            SizedBox(
              height: 3.2.h,
            ),
            Expanded(
              child: Container(
                height: 71.5.h,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),
                  ),
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 7.7.h, left: 6.w),
                      child: Text(
                        "Show Cancelled bookings for",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                            fontSize: 12.sp),
                      ),
                    ),

                    Expanded(
                      child: ListView.builder(

                          itemCount: text7.length,

                          itemBuilder: (context, index) {

                            return Column(
                              children: [
                                Padding(
                                    padding:
                                    EdgeInsets.only( right: 3.w),
                                    child: InkWell(
                                        onTap:(){
                                          setState(() {
                                            value = index;
                                          });

                                        },
                                        child: CustomRadioButton(text7[index],index))
                                ),
                                SizedBox(
                                  height: 1.7.h,
                                ),
                                Divider(
                                  color: Colors.black.withOpacity(0.2),
                                ),
                                SizedBox(
                                  height: 2.h,
                                ),
                              ],
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget CustomRadioButton(String text,int index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding:  EdgeInsets.only(top: 1.h,left: 6.w),
          child: Text(
            text,
            style: (value == index) ?TextStyle(color:  Colors.black ,fontWeight: FontWeight.w800,fontSize: 12.sp):
            TextStyle(color:  Colors.black,fontSize: 12.sp),),
        ),
        Padding(
          padding:  EdgeInsets.only(right: 3.w),
          child: Container(
            height: 4.h,
            width: 4.h,
            decoration: BoxDecoration(
                border: (value == index) ?null:Border.all(color: Colors.grey,width: 0.2.w),
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(2.h)

            ),
            child: Container(
              height:(2.h),
              width:(2.h),
              decoration: BoxDecoration(
                  color: (value == index) ? Colors.lightGreen : Colors.white,
                  borderRadius: BorderRadius.circular(3.h)
              ),
              child: Icon(Icons.check,color: Colors.white,),
            ),
          ),
        ),
      ],
    );

  }
}
