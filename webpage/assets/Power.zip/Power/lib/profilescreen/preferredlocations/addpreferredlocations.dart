import 'package:flutter/material.dart';
import 'package:power/profilescreen/preferredlocations/searchlocation.dart';
import 'package:sizer/sizer.dart';



class Location1 extends StatefulWidget {
  const Location1 ({Key? key}) : super(key: key);

  @override
  _Location1State createState() => _Location1State();
}

class _Location1State extends State<Location1> {
  int value = 0;
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();


  @override
  Widget build(BuildContext context) {return Scaffold(
    backgroundColor: Colors.blue,
    appBar: AppBar(
      automaticallyImplyLeading: false,
      centerTitle: true,
      elevation: 0,
      title: Text('Add Preferred location'),
      actions: [

        IconButton(onPressed: (){Navigator.pop(context);}, icon: Icon(Icons.close))
      ],
    ),

    body: Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(4.h))

      ),
      child: Column(
        mainAxisAlignment:MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding:  EdgeInsets.symmetric(vertical:5.h,horizontal: 5.w ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Preferred Location Type' ,textAlign: TextAlign.start,),
                    SizedBox(
                      height: 2.h,
                    ),

                    Container(
                      width: 90.w,
                      decoration:BoxDecoration(
                          border: Border.all(width: 0.3.w,color: Colors.grey.withOpacity(0.4))
                      ),
                      child: Row(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomRadioButton("Home", 1),
                          CustomRadioButton("Work", 2),
                          CustomRadioButton("Public", 3)
                        ],
                      ),

                    ),
                  ],
                ),

                SizedBox(height:4.h),
                Padding(
                  padding:  EdgeInsets.symmetric(horizontal: 3.h),
                  child: InkWell(
                    onTap:(){Navigator.push(context, MaterialPageRoute(builder: (context)=>Location2()));},
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                            'Preferred Location'
                        ),
                        Icon(Icons.my_location,color:Colors.blue,size:3.5.h),
                      ],
                    ),
                  ),
                ),
                Divider(
                  thickness:0.15.h,
                  color:Colors.black,
                  indent: 21,
                  endIndent: 21,
                ),



              ],
            ),
          ),




          Padding(
            padding:  EdgeInsets.only(
              bottom: 3.h,

            ),
            child: Container(
              height:6.5.h,
              width:80.w,
              decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(10)
              ),

              child:Center(
                child: Text(
                  'Add',
                  style: TextStyle(fontSize: 13.sp, color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    ),

  );}
  Widget CustomRadioButton(String text, int index) {
    return GestureDetector(

      onTap: () {
        setState(() {
          value = index;
        });
      },
      child: Container(
        height:(5.h),
        width:(29.8.w),
        color: (value == index) ? Colors.green : Colors.white,
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: (value == index) ? Colors.white : Colors.black,
            ),
          ),
        ),
      ),
      //shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

    );

  }
}