



import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import 'addpreferredlocations.dart';





class preferred_location extends StatefulWidget {
  const preferred_location ({Key? key}) : super(key: key);

  @override
  _preferred_locationState createState() => _preferred_locationState();
}

class _preferred_locationState extends State<preferred_location> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: Text('Preferred Locations'),
      ),
      bottomNavigationBar: Container(
        color:  Colors.white,
        child: Padding(
          padding:  EdgeInsets.symmetric(vertical:2.h,horizontal: 10.w),
          child: InkWell(
            onTap: () {Navigator.push(context, MaterialPageRoute(builder: (context)=> Location1()));},
            child: Container(
              height:6.5.h,
              width:80.w,
              decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(10)
              ),

              child:Center(
                child: Text(
                  'Add',
                  style: TextStyle(fontSize: 13.sp, color: Colors.white),
                ),
              ),
            ),
          ),
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(4.h))

        ),
        child: Column(
          mainAxisAlignment:MainAxisAlignment.center,
          children: [
            Padding(
              padding:  EdgeInsets.symmetric(vertical:5.h,horizontal: 5.w ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image(height: 90,width:90,image:AssetImage("assets/no location.png")),
                  Text('No locations added !',
                      style:TextStyle(fontWeight: FontWeight.bold,
                          fontSize:3.h)),
                  SizedBox(height:4.h),
                  Text("Looks like, You haven't added any location yet",),
                ],
              ),

            ),

          ],
        ),
      ),
    );}
}