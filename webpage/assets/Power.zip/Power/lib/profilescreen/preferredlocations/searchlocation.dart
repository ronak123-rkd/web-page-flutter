import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class Location2 extends StatefulWidget {
  const Location2 ({Key? key}) : super(key: key);

  @override
  _Location1State createState() => _Location1State();
}

class _Location1State extends State<Location2> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();


  @override
  Widget build(BuildContext context) {return Scaffold(
    body: SafeArea(
      child: Container(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                height: 8.h,
                decoration: BoxDecoration(color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 2.h,
                        spreadRadius: 0.4.h,
                      ),
                    ]),

                child:Row(
                  children: [
                    SizedBox(width:2.h),
                    GestureDetector(onTap: (){Navigator.pop(context);},child: Icon(Icons.arrow_back,color:Colors.blue,size:3.5.h),
                    ),
                    Container(
                      height: 8.h,
                      width: MediaQuery.of(context).size.width-60,
                      child: TextField(
                        style: TextStyle(color: Colors.black),

                        decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderSide: BorderSide.none,
                                borderRadius: BorderRadius.circular(20)),
                            hintText: 'Search Location'
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );}
}