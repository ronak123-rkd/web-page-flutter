import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:power/profilescreen/myaccountscreen/password.dart';
import 'package:sizer/sizer.dart';
import 'updatedata.dart';



class MyAccount extends StatefulWidget {
   const MyAccount({Key? key,}) : super(key: key);

  @override
  State<MyAccount> createState() => _MyAccountState();
}


class _MyAccountState extends State<MyAccount> {

  List<String> text3 = [
    "Name",
    "Email ID",
    "Mobile Number",
    "PIN Code",
    "GSTIN",
    "Password",
  ];

  List<String> text4 = [
    "kirti Kumar",
    "avaiyakirtib@gmail.com",
    "9913157299",
    "395010\nSURAT,Gujrat",
    "Not available",
    "*******",

  ];

  List<String> text5 = [
     "Name",
     "Email ID",
     "Mobile Number",
     "PIN Code",
     "GSTIN",
     "Password",
   ];

   @override
  Widget build(BuildContext context) {
     return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: const Color(0xff4973f5),
        centerTitle: true,
        title:  Text("My Account",style: TextStyle(fontWeight:FontWeight.normal, fontSize: 18.sp),),
      ),
      body: Column(
        children: [

          Container(
            height: 23.h,
            width: MediaQuery.of(context).size.width,
            color: const Color(0xff4973f5),
            child: Align(
              alignment: Alignment.center,
              child: Column(
                children: [
                  SizedBox(height: 2.5.h),
                  Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      height: 12.h,
                      width: 21.w,
                      child: Stack(
                        children: [
                          Container(
                            child: Center(
                              child: Icon(
                                Icons.person_rounded,
                                color: const Color(0xff4973f5),
                                size: 10.h,
                              ),
                            ),
                            height: 12.h,
                            width: 12.h,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12.h)),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              child: Center(
                                  child: Text(
                                    "Public",
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 9.sp),
                                  )),
                              height: 3.2.h,
                              width: 18.5.w,
                              decoration: BoxDecoration(
                                  border: Border.all(color: Colors.white),
                                  color: const Color(0xff4973f5),
                                  borderRadius: BorderRadius.circular(30)),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 2.4.h,
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "kirti Kumar",
                      style: TextStyle(fontSize: 18.sp, color: Colors.white,fontWeight: FontWeight.bold),
                    ),
                  )
                ],
              ),
            ),
          ),
          SizedBox(
            height: 1.h,
          ),
          Expanded(
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(35),
                )
              ),
              child: Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      SizedBox(
                        height: 3.h,
                      ),
                      Text("Personal Info",textAlign: TextAlign.center,style: TextStyle(fontSize:15.sp,fontWeight: FontWeight.bold,color: Colors.black),),
                      SizedBox(
                        height: 6.8.h,
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height/1.5,
                        child: ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),

                           itemCount: text3.length,

                           itemBuilder: (context,index){

                         return   Padding(
                           padding:  EdgeInsets.symmetric(horizontal: 9.5.w,),
                           child: Column(
                             children: [
                               InkWell(
                                 onTap: () async {
                                  if(index == 5){
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>  const Password()),
                                    );
                                  }

                                  else if(index==2){
                                    null;
                                  }else{
                                    await  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>  Name(argument : text4[index], title : text3[index], label : text5[index])),
                                    );
                                  }

                                 },
                                 child: Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Column(
                                       crossAxisAlignment: CrossAxisAlignment.start,
                                       children: [
                                         index == 1 ? Row(
                                           children: [
                                             Text(text3[index],style: TextStyle(fontSize:11.5.sp,color: Colors.black.withOpacity(0.5)),),
                                             SizedBox(
                                               width: 1.w,
                                             ),
                                             Row(
                                               children: [
                                                 Icon   (  Icons.check_circle, color: Colors.green, size: 3.h,),
                                                 SizedBox(
                                                   width: 1.w,
                                                 ),
                                                 Text("Verified",style: TextStyle(fontSize:10.sp,color: Colors.green.withOpacity(0.5)),),
                                               ],
                                             ),
                                           ],
                                         ): Text(text3[index],style: TextStyle(fontSize:11.5.sp,color: Colors.black.withOpacity(0.5)),),
                                         Text(text4[index],style: TextStyle(fontSize:11.sp, color: index == 4 ? Colors.black.withOpacity(0.5) :Colors.black),),
                                       ],
                                     ),
                                     Icon   ( (index == 2) ? null : Icons.arrow_forward_ios_rounded, color: Colors.blue, size: 3.h,)
                                   ],
                                 ),
                               ),
                               SizedBox(
                                 height: 1.7.h,
                               ),
                               Divider(
                                 color: Colors.black.withOpacity(0.2),
                               ),
                               SizedBox(
                                 height: 1.h,
                               ),
                             ],
                           ),
                         );
                           }
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
     );
  }
}


