import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
class Password extends StatefulWidget {
  const Password({Key? key}) : super(key: key);

  @override
  State<Password> createState() => _PasswordState();
}

bool _securText = true;
bool _securText1 = true;


class _PasswordState extends State<Password> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(onWillPop: () async => true,
      child: Scaffold(
        backgroundColor: const Color(0xff4973f5),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0.0,
          backgroundColor: const Color(0xff4973f5),
          centerTitle: true,
          title: Text("Reset Password", style: TextStyle(fontWeight:FontWeight.normal, fontSize: 18.sp)),
          actions: [
            Padding(
              padding:  EdgeInsets.only(right:7.w
              ),
              child: GestureDetector(
                  child: Icon(Icons.close_rounded),
                  onTap: () {
                    Navigator.pop(context);
                  }
              ),
            )
          ],
        ),
        body: Padding(
          padding:  EdgeInsets.only(top: 2.5.h),
          child: Container(
            height: 100.h,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(35),
                topRight: Radius.circular(35),
              ),
              color: Colors.white,
            ),
            child: SingleChildScrollView(
              child: Padding(
                padding:  EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                child: Column(
                  children: [
                    Image.asset("assets/pass.jpg"),
                    SizedBox(
                      height: 1.7.h,
                    ),
                    Text("Set New Password",  style: TextStyle(fontWeight:FontWeight.w500, fontSize: 19.sp, color: Colors.black)),
                    SizedBox(
                      height: 5.h,
                    ),
                    TextFormField(
                      cursorHeight: 5.h,
                      cursorColor: Colors.grey.withOpacity(0.1),
                      decoration: InputDecoration(
                        labelText: "Old Password",
                        labelStyle: TextStyle(color: Colors.grey.withOpacity(0.5)),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 6.6.h,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                          cursorHeight: 5.h,
                          cursorColor: Colors.grey.withOpacity(0.1),
                          decoration: InputDecoration(
                            labelText: "New Password",
                            floatingLabelBehavior: FloatingLabelBehavior.auto,


                            labelStyle: TextStyle(color: Colors.grey.withOpacity(0.5)),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                            ),
                            suffixIcon: Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween, // added line
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.info_outline,color: Colors.grey.withOpacity(0.5),),
                                  SizedBox(
                                    width: 6.w,
                                  ),
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        _securText = !_securText;
                                      });
                                    },
                                    child: Icon(_securText
                                        ? Icons.visibility_off
                                        : Icons.visibility,
                                      color: Colors.grey.withOpacity(0.5),),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 1.5.h,
                        ),
                        Container(
                            height: 6.h,
                            width: 60.w,
                            child: Text("*Tap the info icon to view the password requirements",maxLines: 2, style: TextStyle(fontWeight:FontWeight.w500, fontSize: 9.sp, color: Colors.grey))),
                      ],
                    ),
                    SizedBox(
                      height: 4.h,
                    ),
                    TextFormField(
                      cursorHeight: 5.h,
                      cursorColor: Colors.grey.withOpacity(0.1),
                      decoration: InputDecoration(
                        labelText: "Confirm Password",
                        labelStyle: TextStyle(color: Colors.grey.withOpacity(0.5)),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                        ),
                        suffixIcon: InkWell(
                          onTap: () {
                            setState(() {
                              _securText1 = !_securText1;
                            });
                          },
                          child: Icon(_securText1
                              ? Icons.visibility_off
                              : Icons.visibility,
                            color: Colors.grey.withOpacity(0.5),),
                        ),
                      ),
                    ),

                    SizedBox(
                      height: 6.6.h,
                    ),
                    SizedBox(
                     width: 80.w,
                     height: 7.5.h,
                       child: ElevatedButton(onPressed: (){}, child: Text("Reset"),style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                           borderRadius: BorderRadius.circular(10.0),
                          )
                      ),
                         backgroundColor: MaterialStateProperty.all(Colors.grey.withOpacity(0.6)),
                      )
                     ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),

      ),
    );
  }
}
