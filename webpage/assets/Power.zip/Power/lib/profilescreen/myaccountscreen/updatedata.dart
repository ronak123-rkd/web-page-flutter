import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class Name extends StatefulWidget {
   Name({Key? key,required this.argument,required this.title,required this.label}) : super(key: key);

  final String argument;
  final String title;
  final String label;

  @override
  State<Name> createState() => _NameState();
}

class _NameState extends State<Name> {
  TextEditingController name  = TextEditingController();

  @override
  void initState() {
   name.text = widget.argument.toString();
    super.initState();
  }


  Widget build(BuildContext context) {
    return WillPopScope(onWillPop: () async => true,
      child: Scaffold(
        backgroundColor: const Color(0xff4973f5),
        body: Padding(
          padding: EdgeInsets.only(top: 6.8.h),
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(top: 3.3.h, right: 6.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "Update" + " " + widget.title ,
                      style: TextStyle(
                          fontSize: 18.sp,
                          color: Colors.white,),
                    ),
                    SizedBox(
                      width: 19.w,
                    ),
                    GestureDetector(
                        child: Icon(
                          Icons.close_rounded,
                          color: Colors.white,
                          size: 4.h,
                        ),
                        onTap: () {
                          Navigator.pop(context);
                        }),
                  ],
                ),
              ),
              SizedBox(
                height: 3.3.h,
              ),
              Expanded(
                child: Container(
                  height: 90.h,
                  width: MediaQuery.of(context).size.width,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(35),
                      topRight: Radius.circular(35),),
                  ),
                  child:  Padding(
                    padding: EdgeInsets.symmetric(vertical: 2.6.h,horizontal: 11.w),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:  EdgeInsets.only(top: 4.h),
                              child: Text(widget.label, style: TextStyle(color: Colors.grey.withOpacity(0.5),fontSize: 14.sp, fontWeight: FontWeight.bold),),
                            ),
                            TextFormField(
                              controller:name ,
                              cursorHeight: 5.h,
                              decoration: InputDecoration(
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                                ),
                                focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.5)),
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(
                          width: 80.w,
                          height: 7.5.h,
                          child: ElevatedButton(
                              onPressed: (){

                                },
                              child: Text("Update"),style: ButtonStyle(
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                  )
                              )
                          )
                          ),

                        ),
                      ],
                    ),
                  ),


                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
