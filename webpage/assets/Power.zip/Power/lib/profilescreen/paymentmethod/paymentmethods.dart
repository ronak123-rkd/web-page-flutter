import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../homepage.dart';
import 'account_transaction.dart';
class Payment extends StatelessWidget {
  const Payment({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      body: Padding(
        padding: EdgeInsets.only(top: 6.9.h),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(left: 7.w),
              child: Row(
                children: [
                  GestureDetector(
                      child: Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()),
                      );}
                  ),
                  SizedBox(
                    width: 13.w,
                  ),
                  Text("Payment Methods", style: TextStyle(fontSize: 18.sp,  color: Colors.white),),
                  SizedBox(
                    width: 13.w,
                  ),

                ],
              ),
            ),
            SizedBox(height:3.h ),
            Container(
              height:78.2.h,
              width:  MediaQuery.of(context).size.width,
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(35),
                  topRight: Radius.circular(35),
                ),
                color: Colors.white,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 2.3.h),
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => Account_Transaction() ),
                  );
                },
                child: Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Account Transaction History",
                        style: TextStyle(fontSize: 13.sp, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
