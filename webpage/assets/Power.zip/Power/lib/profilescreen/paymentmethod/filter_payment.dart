import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class FilterPayment extends StatefulWidget {
  const FilterPayment({Key? key}) : super(key: key);

  @override
  State<FilterPayment> createState() => _Filter123State();
}

class _Filter123State extends State<FilterPayment> {

  int value = 0;

  List<String> text2 = [
    "Last one Month",
    "Last 3 Monts",
    "Last 6 monts",
    "Last 1 year",

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.blue,
      body: Padding(
        padding: EdgeInsets.only(top: 6.8.h),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 1.h, right: 6.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Time filter",
                    style: TextStyle(
                        fontSize: 19.sp,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: 23.w,
                  ),
                  GestureDetector(
                      child: Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      }),
                ],
              ),
            ),
            SizedBox(
              height: 3.2.h,
            ),
            Expanded(
              child: Container(
                height: 71.5.h,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),
                  ),
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 7.7.h, left: 6.w),
                      child: Text(
                        "Show transactions for",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            fontSize: 12.sp),
                      ),
                    ),

                    Expanded(
                      child: ListView.builder(

                          itemCount: text2.length,

                          itemBuilder: (context, index) {

                            return Column(
                              children: [
                                Padding(
                                    padding:
                                    EdgeInsets.only( right: 3.w),
                                    child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            value = index;
                                          });

                                        },
                                        child: CustomRadioButton(text2[index],index))
                                ),
                                SizedBox(
                                  height: 1.7.h,
                                ),
                                Divider(
                                  color: Colors.black.withOpacity(0.2),
                                ),
                                SizedBox(
                                  height: 2.h,
                                ),
                              ],
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              height: 9.18.h,
              width: MediaQuery.of(context).size.width,
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FlatButton(
                    onPressed: () {},
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1.h)),
                    child:  Text("Clear",style: TextStyle(fontWeight:FontWeight.w500, fontSize: 12.sp,color: Colors.black)),
                    height: 7.h,
                    minWidth: 40.w,
                  ),
                  FlatButton(
                    onPressed: () {Navigator.pop(context);},
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1.h)),
                    child:  Text("Apply",style: TextStyle(fontWeight:FontWeight.w500, fontSize: 12.sp,color: Colors.white)),
                    color: Colors.blue,
                    height: 7.h,
                    minWidth: 40.w,
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget CustomRadioButton(String text,int index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding:  EdgeInsets.only(top: 1.h,left: 6.w),
          child: Text(
            text,
            style: (value == index) ?TextStyle(color:  Colors.black ,fontWeight: FontWeight.w800,fontSize: 12.sp):
            TextStyle(color:  Colors.black,fontSize: 12.sp),),
        ),
        Padding(
          padding:  EdgeInsets.only(right: 3.w),
          child: Container(
            height: 4.h,
            width: 4.h,
            decoration: BoxDecoration(
                border: (value == index) ?null:Border.all(color: Colors.grey,width: 0.2.w),
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(2.h)

            ),
            child: Container(
              height:(2.h),
              width:(2.h),
              decoration: BoxDecoration(
                  color: (value == index) ? Colors.lightGreen : Colors.white,
                  borderRadius: BorderRadius.circular(3.h)
              ),
              child: Icon(Icons.check,color: Colors.white,),
            ),
          ),
        ),
      ],
    );

  }
}