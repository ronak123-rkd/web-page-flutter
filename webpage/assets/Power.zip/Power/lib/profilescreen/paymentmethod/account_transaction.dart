import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import 'filter_payment.dart';


class Account_Transaction extends StatelessWidget {
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.blue,
      body: Column(
        children: [
          Container(
            color: Colors.blue,
            width: MediaQuery.of(context).size.width,
            height: 100.0,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 3.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(Icons.arrow_back, size: 3.5.h),
                  ),
                  Center(
                    child: Text(
                      "Account Transaction History",
                      style: TextStyle(color: Colors.white, fontSize: 18.0),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => FilterPayment()));
                    },
                    child: Container(
                        height: 3.h,
                        width: 5.w,
                        child: (Image.asset('assets/filter1.png'))),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                Container(
                  width: 100.w,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                      BorderRadius.vertical(top: Radius.circular(3.h))),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(
                            vertical: 5.h, horizontal: 5.w),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                            Image(
                            height: 90,
                            width: 90,
                            image: AssetImage("assets/no location.png")),

                        SizedBox(height: 4.h),
                        Text(
                            "No Account Transaction History !",
                            style:TextStyle(color: Colors.black,fontWeight: FontWeight.bold)
                        ),
                        Text("Looks like, you do not have any account transaction history yet",
                          style:TextStyle(color: Colors.grey,fontWeight: FontWeight.bold))
                          ]
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: -4.h,
                  left: 6.h,
                  right: 6.h,
                  child: Card(
                    child: Container(
                      height: 6.h,
                      padding: EdgeInsets.symmetric(horizontal: 5.w),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          color: Colors.white),
                      child: Row(
                        children: [
                          Center(
                            child: Text(
                              "TATA POWER EZ Charge Account",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),

                        ],
                      ),

                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}