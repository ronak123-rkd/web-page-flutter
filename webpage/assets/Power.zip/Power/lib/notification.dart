import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class Notification1 extends StatefulWidget {
  const Notification1 ({Key? key}) : super(key: key);

  @override
  _NotificationState createState() => _NotificationState();
}

class _NotificationState extends State<Notification1> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: Text('Notifications'),
      ),
      body: Container(
          child: Column(
              children:[
                Container(
                  height: 79.h,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(20),
                      )
                  ),
                  child:Column(
                      children: [
                        Container(
                            height:15.h,
                            width:MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(

                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(20),

                                ),
                                   
                            ),
                            child:Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:[
                                    SizedBox(height: 2.h),

                                    Text("System Maintenance Downtime",
                                        textAlign: TextAlign.start,
                                        style:TextStyle(fontWeight: FontWeight.bold)
                                    ),
                                    SizedBox(height: 1.h),
                                    Text('''Dear Customer,System main System maintainace activity is planned tonight due to which charging services will not be available from 00:00 hrs to 2:00 hrs . kindly plan your charging sessions''',
                                        style:TextStyle(fontSize:11))
                                  ]

                              ),
                            )
                        ),
                        Divider(
                          thickness:0.01.h,
                          color:Colors.black,
                        ),
                        SizedBox(height: 0.3.h),
                        Container(
                            height:15.h,
                            width:MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(

                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(20),
                                )
                            ),
                            child:Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:[
                                    SizedBox(height: 2.h),

                                    Text("System Maintenance Downtime",
                                        textAlign: TextAlign.start,
                                        style:TextStyle(fontWeight: FontWeight.bold)
                                    ),
                                    SizedBox(height: 1.h),
                                    Text('''Dear Customer,System main System maintainace activity is planned tonight due to which charging services will not be available from 00:00 hrs to 2:00 hrs . kindly plan your charging sessions''',
                                        style:TextStyle(fontSize:11))
                                  ]

                              ),
                            )
                        ),
                        Divider(
                          thickness:0.01.h,
                          color:Colors.black,
                        ),
                        SizedBox(height: 0.09.h),
                        Container(
                            height:15.h,
                            width:MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(

                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(20),
                                )
                            ),
                            child:Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:[
                                    SizedBox(height: 2.h),

                                    Text("Misssing Profile details.",
                                        textAlign: TextAlign.start,
                                        style:TextStyle(fontWeight: FontWeight.bold)
                                    ),
                                    SizedBox(height: 1.h),
                                    Text('''Dear Customer,System main System maintainace activity is planned tonight due to which charging services will not be available from 00:00 hrs to 2:00 hrs . kindly plan your charging sessions''',
                                        style:TextStyle(fontSize:11))
                                  ]

                              ),
                            )
                        ),

                      ]),


                ),
                Container(height:8.h,
                  child:Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 1.5.w,
                      ),
                      Text(
                        'Clear All',
                        style: TextStyle(fontSize: 13.sp, color: Colors.white),
                      ),
                    ],
                  ),)

              ]
          )

      ),

    );}
}