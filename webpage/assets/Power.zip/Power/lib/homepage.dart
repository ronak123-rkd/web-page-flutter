import 'dart:ui';
import 'filter.dart';
import 'listview.dart';
import 'package:power/search.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:power/notification.dart';
import 'package:power/profilescreen/ezchargecard/ezchargecard.dart';
import 'package:power/profilescreen/help&support/helpsupport.dart';
import 'package:power/profilescreen/myaccountscreen/myaccount.dart';
import 'package:power/profilescreen/myboking/mybooking.dart';
import 'package:power/profilescreen/myusage/myusage.dart';
import 'package:power/profilescreen/paymentmethod/paymentmethods.dart';
import 'package:power/profilescreen/preferredlocations/preferredlocations.dart';
import 'package:power/profilescreen/privacypolicy/privacypolicy.dart';
import 'package:power/profilescreen/term&conditions/termsconditions.dart';
import 'package:power/profilescreen/vehiclesscreen/myvehicles.dart';
import 'profilescreen/chargingscreen/charginghistory.dart';



class HomePage extends StatelessWidget {
  HomePage({Key? key}) : super(key: key);

  final screen=[
    MyAccount(),
    ChargingHistory(),
    Vehicles(),
    Charge_card(),
    MyUsage(),
    preferred_location(),
    Payment(),
    MyBooking(),
    help_support(),
  ];

  List<String> text1 = [
    "My Account",
    "Charging History",
    "My Vehicles",
    "EZ Charge Card",
    "My Usage",
    "Preferred Locations",
    "Payment Methods",
    "My Bookings",
    "Help & Support"
  ];

  List<IconData> icons = [
    Icons.perm_identity,
    Icons.access_time_rounded,
    Icons.directions_car_outlined,
    Icons.charging_station_outlined,
    Icons.leaderboard_outlined,
    Icons.location_on_outlined,
    Icons.payment,
    Icons.table_chart_outlined,
    Icons.help_outline,
  ];





  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: Drawer(
          child: Column(
            children: [
              Container(
                height: 31.h,
                width: MediaQuery.of(context).size.width,
                color: Colors.white,
                child: Padding(
                  padding: EdgeInsets.only(top: 10.h,left: 10.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          Container(
                            child: Stack(
                              children: [
                                Padding(
                                  padding:  EdgeInsets.only(left: 2.0),
                                  child: Icon(
                                    Icons.person_rounded,
                                    color: Colors.white,
                                    size: 9.h,
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    child: Center(
                                        child: Text(
                                          "Public",
                                          style: TextStyle(
                                              color: Colors.white, fontSize: 9.sp),
                                        )),
                                    height: 2.5.h,
                                    width: 15.w,
                                    decoration: BoxDecoration(
                                        border: Border.all(color: Colors.white),
                                        color:  Color(0xff4973f5),
                                        borderRadius: BorderRadius.circular(30)),
                                  ),
                                )
                              ],
                            ),
                            height:9.h,
                            width: 9.h,
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(9.h)),
                          ),

                        ],
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Text(
                        "kirti Kumar",
                        style: TextStyle(fontSize: 20.sp),
                      )
                    ],
                  ),
                ),
              ),
              Divider(
                color: Colors.black.withOpacity(0.2),
                height: 0.1.h,
              ),
              Container(
                  height: 51.5.h,
                  width: MediaQuery.of(context).size.width,
                  color: Colors.white,
                  child: Padding(
                    padding: EdgeInsets.only(top: 2.h),
                    child: ListView.builder(

                        itemCount: icons.length,

                        itemBuilder: (context, index) {
                          return Padding(
                            padding: EdgeInsets.only(
                                left: 10.w, top: 0.2.h, bottom: 3.1.h),
                            child: Column(
                              children: [
                                InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>  screen[index]),
                                    );
                                  },
                                  child: Row(
                                    children: [
                                      Icon(
                                        icons[index],
                                        color: const Color(0xff4973f5),
                                        size: 2.7.h,
                                      ),
                                      SizedBox(
                                        width: 5.3.w,
                                      ),
                                      Text(
                                        text1[index],
                                        style: TextStyle(fontSize: 13.sp),
                                      )
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 1.5.h,
                                ),
                              ],
                            ),
                          );
                        }),
                  )),
              Divider(
                color: Colors.black.withOpacity(0.2),
                height: 0.1.h,
              ),
              Container(
                height: 7.6.h,
                width: MediaQuery.of(context).size.width,
                color: Colors.white,
                child: Padding(
                  padding: EdgeInsets.only(left: 10.w),
                  child: Row(
                    children: [
                      Icon(
                        Icons.logout,
                        color: const Color(0xff4973f5),
                        size: 3.5.h,
                      ),
                      SizedBox(
                        width: 4.9.w,
                      ),
                      Text(
                        "Logout",
                        style: TextStyle(fontSize: 13.sp),
                      )
                    ],
                  ),
                ),
              ),
              Divider(
                color: Colors.black.withOpacity(0.2),
                height: 0.2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 10.w, top: 3.3.h),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>  PrivacyPolicy()),
                        );
                      },
                      child: Text("Privacy Policy",
                          style: TextStyle(
                              fontSize: 11.sp,
                              color: Colors.black45,
                              fontWeight: FontWeight.w500)),
                    ),
                    SizedBox(
                      width: 3.w,
                    ),
                    Container(
                      height: 2.3.h,
                      width: 0.15.w,
                      color: Colors.black.withOpacity(0.7),
                    ),
                    SizedBox(
                      width: 2.w,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => TermConditions()),
                        );
                      },
                      child: Text("Terms & Conditions",
                          style: TextStyle(
                              fontSize: 11.sp,
                              color: Colors.black45,
                              fontWeight: FontWeight.w500)),
                    ),
                  ],
                ),
              ),
            ],
          )),
      floatingActionButton: Padding(
        padding:  EdgeInsets.only(top: 67.h),
        child: Column(
          children: [
            FloatingActionButton(
              backgroundColor:  Colors.white,
              child: const Icon(
                Icons.my_location,
                color: Colors.blue,
                size: 26,
              ),
              onPressed: () {


              },
            ),
            SizedBox(
              height: 3.h,
            ),
            FloatingActionButton(
              backgroundColor:  Colors.white,
              child: const Icon(
                Icons.list,
                color: Colors.blue,
                size: 29,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>  Listing()),
                );
              },
            ),
          ],
        ),
      ),

      backgroundColor: const Color(0xff4973f5),
      body: Padding(
        padding: EdgeInsets.only(top: 8.h),
        child: Column(
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              GestureDetector(
                child: Padding(
                  padding: EdgeInsets.only(left: 2.w),
                  child: Icon(
                    Icons.account_circle_sharp,
                    color: Colors.white,
                    size: 5.2.h,
                  ),
                ),
                onTap: () => _scaffoldKey.currentState!.openDrawer(),
              ),
              Container(
                child: Padding(
                  padding: EdgeInsets.only(left: 3.w),
                  child: Text(
                    "Public",
                    style: TextStyle(color: Colors.white, height: 0.3.h),
                    textAlign: TextAlign.left,
                  ),
                ),
                height: 4.8.h,
                width: 47.w,
                decoration: BoxDecoration(
                    color: const Color(0xff3067b9),
                    borderRadius: BorderRadius.circular(30)),
                //   child:   TextField(
                //     textAlign: TextAlign.start,
                //     decoration: InputDecoration(
                //       hintText: ("Public"),
                //       hintStyle:TextStyle(color: Colors.white, fontSize: 2.h, height: 0.1.h),
                //       border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(30.0),
                //       ),
                //     ),
                // ),
              ),
              SizedBox(
                width: 1.w,
              ),
              Row(
                children: [
                  GestureDetector(
                    child: Icon(
                      Icons.search_sharp,
                      color: Colors.white,
                      size: 4.2.h,
                    ),
                    onTap: () {
                       Navigator.push(context, MaterialPageRoute(builder: (context)=>Search()));
                    },
                  ),
                  SizedBox(
                    width: 4.w,
                  ),
                  GestureDetector(
                    child: Icon(
                      Icons.filter_alt_outlined,
                      color: Colors.white,
                      size: 4.h,
                    ),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Filter()));
                    },
                  ),
                  SizedBox(
                    width: 4.w,
                  ),
                  GestureDetector(
                    child: Icon(
                      Icons.notifications_none_sharp,
                      color: Colors.white,
                      size: 4.h,
                    ),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Notification1()));
                    },
                  ),
                ],
              ),
            ]),
            Padding(
              padding: EdgeInsets.only(top: 4.h),
              child: Container(
                height: 74.h,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),
                  ),
                  color: Colors.white,
                ),

              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 2.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.qr_code_scanner,
                    color: Colors.white,
                    size: 4.h,
                  ),
                  SizedBox(
                    width: 1.5.w,
                  ),
                  Text(
                    'Scan QRCode',
                    style: TextStyle(fontSize: 13.sp, color: Colors.white),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
