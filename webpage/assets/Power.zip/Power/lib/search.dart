import 'package:flutter/material.dart';
import 'package:power/profilescreen/preferredlocations/addpreferredlocations.dart';
import 'package:sizer/sizer.dart';



class Search extends StatefulWidget {
  const Search ({Key? key}) : super(key: key);

  @override
  _SearchState createState() => _SearchState();
}

class _SearchState extends State<Search> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();


  @override
  Widget build(BuildContext context) {return Scaffold(
    body: SafeArea(
      child: Container(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                height: 8.h,


                decoration: BoxDecoration(color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 2.h,
                        spreadRadius: 0.4.h,
                      ),
                    ]),

                child:Row(
                  children: [

                    GestureDetector(onTap: (){Navigator.pop(context);},child: Icon(Icons.arrow_back,color:Colors.blue,size:3.5.h),
                    ),
                    Container(
                      height: 8.h,
                      width: MediaQuery.of(context).size.width-60,
                      child: TextField(
                        style: TextStyle(color: Colors.black),
                        decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderSide: BorderSide.none,
                                borderRadius: BorderRadius.circular(20)),
                            hintText: 'Search Location'
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height:3.h),
            Container(

                child:Row(
                    children:[
                      SizedBox(width:4.h),
                      GestureDetector(onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context)=>Location1()));},child: Icon(Icons.add_circle_outline,size: 3.5.h,color:Colors.green),
                      ),
                      SizedBox(width:2.5.h),

                      Text('Add Preferred Location')
                    ]
                )
            )
          ],
        ),
      ),
    ),
  );}
}