import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class ViewTariff extends StatelessWidget {
  const ViewTariff({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff4973f5),
      body:  Padding(
        padding: EdgeInsets.only(top: 6.8.h),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 4.h,left: 10.w ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      Text(
                        "Tata Motors (Pramukh Auto)",
                        textAlign: TextAlign.start,
                        style: TextStyle(
                            fontSize: 18.sp,
                            color: Colors.white,
                            ),
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Container(
                        height: 2.h,
                        width: 70.w,
                        child: Text(
                          "Plot No.409/27A, Umiya Nagar Society,Near.. Chosath Jogni Mata Temple",
                          style: TextStyle(
                              fontSize: 10.sp,
                              color: Colors.white,
                             ),
                        ),
                      ),
                      SizedBox(
                        width: 3.w,
                      ),

                    ],
                  ),
                  GestureDetector(
                      child: Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 5.h,
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      }),
                ],
              ),
            ),

            SizedBox(
              height:
              4.h,
            ),
            Container(
              height: 4.h,
              width: 50.w,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.white),
                  color:  Color(0xff4973f5),
                  borderRadius: BorderRadius.circular(30)),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text(
                      "Charger A",
                      style: TextStyle(
                          color: Colors.white, fontSize: 9.sp),
                    ),
                    Container(
                      height: 2.3.h,
                      width: 0.15.w,
                      color: Colors.white,
                    ),
                    Text(
                      "Charging point 2",
                      style: TextStyle(
                          color: Colors.white, fontSize: 9.sp),
                    ),
                  ],
                ),
              ),
            ),
            Row(

            ),
            Padding(
              padding:  EdgeInsets.only(top: 4.h ,left: 10.w),
              child: Row(
                children: [
                  CircleAvatar(radius: (4.h),
                      backgroundColor: Colors.white,
                      child: ClipRRect(
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Image.asset("assets/charg.png"),
                        ),
                      )
                  ),
                  SizedBox(
                    width: 3.w,
                  ),
                  Padding(
                    padding:  EdgeInsets.only(top: 4.h),
                    child: Column(
                      crossAxisAlignment:CrossAxisAlignment.start ,
                      children: [
                        Text("CCS-2",style: TextStyle(fontSize: 12.sp,color: Colors.white),),
                        SizedBox(
                          height: 2.w,
                        ),
                        Text("Capacity: 25kW",style: TextStyle(fontSize: 12.sp,color: Colors.white),),
                        SizedBox(
                          height: 2.w,
                        ),
                        Text("₹ 112.50/15 mins(Estimated*)",style: TextStyle(fontSize: 12.sp,color: Colors.white),),
                        SizedBox(
                          height: 2.w,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                  height: 71.5.h,
                  width: MediaQuery.of(context).size.width,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(35),
                      topRight: Radius.circular(35),
                    ),
                    color: Colors.white,
                  ),
                  child:  Column(
                    // mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text("Tariff Breakup",style: TextStyle(fontSize: 15.sp,color: Colors.black, fontWeight: FontWeight.bold),),
                      SizedBox(
                        height: 5.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text("service Charges (₹ per kwh):"),
                          Text("₹18.00")
                        ],
                      ),
                      Text("*These charges are exclusive of taxes and discounts."),
                      Text("They can vary as per the actual consumption"),

                      FlatButton(
                        onPressed: () {
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => Add()),);
                        },
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(2.h)),
                        child:  Text("Add",style: TextStyle(fontWeight:FontWeight.w500, fontSize: 12.sp,color: Colors.white)),
                        color: Colors.blue,
                        height: 7.5.h,
                        minWidth: 80.w,
                      ),
                    ],
                  )
              ),
            )

          ],
        ),
      ),
    );
  }
}




