import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:power/homepage.dart';
import 'package:power/profilescreen/ezchargecard/ezchargecard.dart';
import 'package:power/profilescreen/help&support/helpsupport.dart';
import 'package:power/profilescreen/myaccountscreen/myaccount.dart';
import 'package:power/profilescreen/myboking/mybooking.dart';
import 'package:power/profilescreen/myusage/myusage.dart';
import 'package:power/profilescreen/paymentmethod/paymentmethods.dart';
import 'package:power/profilescreen/preferredlocations/preferredlocations.dart';
import 'package:power/profilescreen/privacypolicy/privacypolicy.dart';
import 'package:power/profilescreen/term&conditions/termsconditions.dart';
import 'package:power/profilescreen/vehiclesscreen/myvehicles.dart';
import 'package:power/search.dart';
import 'package:power/viewtariff.dart';
import 'package:sizer/sizer.dart';
import 'filter.dart';
import 'notification.dart';
import 'profilescreen/chargingscreen/charginghistory.dart';

class Listing extends StatelessWidget {
  Listing({Key? key}) : super(key: key);

  final screen = [
    MyAccount(),
    ChargingHistory(),
    Vehicles(),
    Charge_card(),
    MyUsage(),
    preferred_location(),
    Payment(),
    MyBooking(),
    help_support(),
  ];

  List<String> text1 = [
    "My Account",
    "Charging History",
    "My Vehicles",
    "EZ Charge Card",
    "My Usage",
    "Preferred Locations",
    "Payment Methods",
    "My Bookings",
    "Help & Support"
  ];

  List<IconData> icons = [
    Icons.perm_identity,
    Icons.access_time_rounded,
    Icons.directions_car_outlined,
    Icons.charging_station_outlined,
    Icons.leaderboard_outlined,
    Icons.location_on_outlined,
    Icons.payment,
    Icons.table_chart_outlined,
    Icons.help_outline,
  ];

  List<String> text0 = [
    "Tata Motors (Pramukh Auto)",
    "Tata Motors (Shreeji Automart)",
    "IOCL Omakar Petroleum",

  ];

  List<String> texta = [
    "Plot No.409/27A, Umiya Nagar Society,Near Chosath Jogni Mata Temple",
    "04 A/b, Shreeji House,Opp.Big Bazar,Dumas Road",
    "High Tension Rd, Subhanpura, Vadodara",
  ];

  List<String> text2 = [
    "charger A",
    "charger A",
    "charger B",
    "charger B",
  ];

  List<String> image = [
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png",
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png",
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png",
    "https://www.evexpert.eu/resize/af/212/201/files/basics-of-electromobility/konektory/chademo.png"
  ];

  List<String> text3 = [
    "CHAdeMO",
    "CCS-2",
    "BHarat DC0011 GB/T",
    "AC Type-2"
  ];

  List<String> text4 = [
    "₹ 112.50/15 mins",
    "₹ 112.50/15 mins",
    "₹ 67.50/15 mins",
    "₹ 33.30/15 mins",
  ];

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => true,
      child: Scaffold(
        key: _scaffoldKey,
        drawer: Drawer(
            child: Column(
             children: [
             Container(
              height: 31.h,
              width: MediaQuery.of(context).size.width,
              color: Colors.white,
              child: Padding(
                padding: EdgeInsets.only(top: 10.h, left: 10.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        Container(
                          child: Stack(
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: 2.0),
                                child: Icon(
                                  Icons.person_rounded,
                                  color: Colors.white,
                                  size: 9.h,
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  child: Center(
                                      child: Text(
                                    "Public",
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 9.sp),
                                  )),
                                  height: 2.5.h,
                                  width: 15.w,
                                  decoration: BoxDecoration(
                                      border: Border.all(color: Colors.white),
                                      color: Color(0xff4973f5),
                                      borderRadius: BorderRadius.circular(30)),
                                ),
                              )
                            ],
                          ),
                          height: 9.h,
                          width: MediaQuery.of(context).size.width < 400
                              ? MediaQuery.of(context).size.width / 5.9
                              : MediaQuery.of(context).size.width / 4,
                          decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(100)),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 2.h,
                    ),
                    Text(
                      "kirti Kumar",
                      style: TextStyle(fontSize: 20.sp),
                    )
                  ],
                ),
              ),
            ),
            Divider(
              color: Colors.black.withOpacity(0.2),
              height: 0.1.h,
            ),
            Container(
                height: 51.5.h,
                width: MediaQuery.of(context).size.width,
                color: Colors.white,
                child: Padding(
                  padding: EdgeInsets.only(top: 2.h),
                  child: ListView.builder(
                      itemCount: icons.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: EdgeInsets.only(
                              left: 10.w, top: 0.2.h, bottom: 3.1.h),
                          child: Column(
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => screen[index]),
                                  );
                                },
                                child: Row(
                                  children: [
                                    Icon(
                                      icons[index],
                                      color: const Color(0xff4973f5),
                                      size: 2.7.h,
                                    ),
                                    SizedBox(
                                      width: 5.3.w,
                                    ),
                                    Text(
                                      text1[index],
                                      style: TextStyle(fontSize: 13.sp),
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 1.5.h,
                              ),
                            ],
                          ),
                        );
                      }),
                )),
            Divider(
              color: Colors.black.withOpacity(0.2),
              height: 0.1.h,
            ),
            Container(
              height: 7.6.h,
              width: MediaQuery.of(context).size.width,
              color: Colors.white,
              child: Padding(
                padding: EdgeInsets.only(left: 10.w),
                child: Row(
                  children: [
                    Icon(
                      Icons.logout,
                      color: const Color(0xff4973f5),
                      size: 3.5.h,
                    ),
                    SizedBox(
                      width: 4.9.w,
                    ),
                    Text(
                      "Logout",
                      style: TextStyle(fontSize: 13.sp),
                    )
                  ],
                ),
              ),
            ),
            Divider(
              color: Colors.black.withOpacity(0.2),
              height: 0.2.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 10.w, top: 3.3.h),
              child: Row(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PrivacyPolicy()),
                      );
                    },
                    child: Text("Privacy Policy",
                        style: TextStyle(
                            fontSize: 11.sp,
                            color: Colors.black45,
                            fontWeight: FontWeight.w500)),
                  ),
                  SizedBox(
                    width: 3.w,
                  ),
                  Container(
                    height: 2.3.h,
                    width: 0.15.w,
                    color: Colors.black.withOpacity(0.7),
                  ),
                  SizedBox(
                    width: 2.w,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => TermConditions()),
                      );
                    },
                    child: Text("Terms & Conditions",
                        style: TextStyle(
                            fontSize: 11.sp,
                            color: Colors.black45,
                            fontWeight: FontWeight.w500)),
                  ),
                ],
              ),
            ),
          ],
        )),
        floatingActionButton: Padding(
          padding: const EdgeInsets.only(bottom: 70.0),
          child: FloatingActionButton(
            backgroundColor: const Color(0xfff6c400),
            child: const Icon(
              Icons.map,
              color: Colors.white,
              size: 29,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomePage()),
              );
            },
          ),
        ),
        backgroundColor: const Color(0xff4973f5),
        body: Padding(
          padding: EdgeInsets.only(top: 8.h),
          child: Column(
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                GestureDetector(
                  child: Padding(
                    padding: EdgeInsets.only(left: 2.w),
                    child: Icon(
                      Icons.account_circle_sharp,
                      color: Colors.white,
                      size: 5.2.h,
                    ),
                  ),
                  onTap: () => _scaffoldKey.currentState!.openDrawer(),
                ),
                Container(
                  child: Padding(
                    padding: EdgeInsets.only(left: 3.w),
                    child: Text(
                      "Public",
                      style: TextStyle(color: Colors.white, height: 0.3.h),
                      textAlign: TextAlign.left,
                    ),
                  ),
                  height: 4.8.h,
                  width: 47.w,
                  decoration: BoxDecoration(
                      color: const Color(0xff3067b9),
                      borderRadius: BorderRadius.circular(30)),
                  //   child:   TextField(
                  //     textAlign: TextAlign.start,
                  //     decoration: InputDecoration(
                  //       hintText: ("Public"),
                  //       hintStyle:TextStyle(color: Colors.white, fontSize: 2.h, height: 0.1.h),
                  //       border: OutlineInputBorder(
                  //         borderRadius: BorderRadius.circular(30.0),
                  //       ),
                  //     ),
                  // ),
                ),
                SizedBox(
                  width: 1.w,
                ),
                Row(
                  children: [
                    GestureDetector(
                      child: Icon(
                        Icons.search_sharp,
                        color: Colors.white,
                        size: 4.2.h,
                      ),
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Search()));
                      },
                    ),
                    SizedBox(
                      width: 4.w,
                    ),
                    GestureDetector(
                      child: Icon(
                        Icons.filter_alt_outlined,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Filter()));
                      },
                    ),
                    SizedBox(
                      width: 4.w,
                    ),
                    GestureDetector(
                      child: Icon(
                        Icons.notifications_none_sharp,
                        color: Colors.white,
                        size: 4.h,
                      ),
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Notification1()));
                      },
                    ),
                  ],
                ),
              ]),
              Padding(
                padding: EdgeInsets.only(top: 4.h),
                child: Container(
                  child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 2.9.h,vertical: 0.7.h),
                      child: ListView.builder(
                          itemCount: text0.length,
                          itemBuilder: (context, index) {
                            return Column(
                              children: [
                                Padding(
                                    padding: EdgeInsets.only(
                                      top: 1.h,
                                    ),
                                    child: Row(
                                      children: [
                                        Text(text0[index],
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 12.5.sp,
                                                fontWeight: FontWeight.w500)),
                                        SizedBox(
                                          width: 2.2.w,
                                        ),
                                        Container(
                                          child: Center(
                                              child: Text(
                                            "Public",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 9.sp),
                                          )),
                                          height: 3.h,
                                          width: 16.w,
                                          decoration: BoxDecoration(
                                              color: const Color(0xff75bdec),
                                              borderRadius:
                                                  BorderRadius.circular(30)),
                                        )
                                      ],
                                    )),
                                SizedBox(
                                  height: 1.3.h,
                                ),
                                 Text(
                                    texta[index],
                                     maxLines: 2,
                                    style: TextStyle(
                                        color: Colors.black54,
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.w500)),
                                SizedBox(
                                  height: 2.8.h,
                                ),
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    child: Center(
                                        child: Text(
                                      "Open",
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 9.sp),
                                    )),
                                    height: 3.h,
                                    width: 14.w,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff9cca22),
                                        borderRadius:
                                            BorderRadius.circular(30)),
                                  ),
                                ),
                                SizedBox(
                                  height: 2.h,
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.fmd_good,
                                      color: const Color(0xff3b7ad9),
                                      size: 2.5.h,
                                    ),
                                    SizedBox(
                                      width: 1.5.w,
                                    ),
                                    Text(
                                      '3.5 Km',
                                      style: TextStyle(
                                          fontSize: 12.sp,
                                          color: Colors.black54,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    SizedBox(
                                      width: 7.w,
                                    ),
                                    Icon(
                                      Icons.watch_later_rounded,
                                      color: const Color(0xff3b7ad9),
                                      size: 2.5.h,
                                    ),
                                    SizedBox(
                                      width: 1.5.w,
                                    ),
                                    SizedBox(
                                      width: 23.w,
                                      child: Text(
                                        '12.00 AM- 11.59 PM',
                                        maxLines: 2,
                                        style: TextStyle(
                                            fontSize: 12.sp,
                                            color: Colors.black54,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 3.h,
                                ),
                                Row(
                                  children: [
                                    Text("Available Connectors 2/2 ",
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 14.sp,
                                            fontWeight: FontWeight.w500)),
                                    SizedBox(
                                      width: 4.w,
                                    ),
                                    Container(
                                      height: 3.8.h,
                                      width: 21.8.w,
                                      decoration: BoxDecoration(
                                          border:
                                          Border.all(color: Colors.blue),
                                          borderRadius:
                                          BorderRadius.circular(10)),
                                      child: Row(
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.only(
                                                left: 1.8.w, top: 0.1.h),
                                            child: Text("Navigate",style: TextStyle(color: const Color(0xff3068b7),
                                                fontSize: 9.sp,
                                                fontWeight: FontWeight.w500),
                                            ),
                                          ),
                                          Icon(
                                            Icons.send,
                                            color: Colors.blue,
                                            size: 2.5.h,
                                          ),
                                        ],
                                      ),

                                    )
                                  ],
                                ),
                                SizedBox(
                                  height: 2.3.h,
                                ),
                                SizedBox(
                                  height: 25.h,
                                  width: 100.w,
                                  child: ListView.builder(
                                      scrollDirection: Axis.horizontal,
                                      shrinkWrap: true,
                                      itemCount: text2.length,
                                      itemBuilder: (context, index) {
                                        return Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 2.w),
                                          child: Card(
                                            shape:  RoundedRectangleBorder (
                                              borderRadius: BorderRadius.circular(15),
                                              ),
                                            child: Container(
                                              height: 23.5.h,
                                              width: 28.w,
                                              child: Column(
                                                children: [
                                                  Container(
                                                    height: 3.8.h,
                                                    decoration:
                                                        const BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.vertical(
                                                              top: Radius
                                                                  .circular(
                                                                      15)),
                                                      color: Color(0xff3b7ad9),
                                                    ),
                                                    child: Row(
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  left: 4.w),
                                                          child: Text(
                                                            text2[index],
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontSize: 9.sp),
                                                          ),
                                                        ),
                                                        SizedBox(width: 1.8.w),
                                                        SizedBox(
                                                            width: 6.w,
                                                            child: Image.network(
                                                                "https://icon-library.com/images/number-one-png-black-and-white-1st-icon-1600_86403.png"))
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 2.8.h,
                                                  ),
                                                  SizedBox(
                                                      height: 6.h,
                                                      width: 9.w,
                                                      child: Image.network(
                                                          image[index])),
                                                  SizedBox(
                                                    height: 0.1.h,
                                                  ),
                                                  Text(
                                                    text3[index],
                                                    style: TextStyle(
                                                        color: Colors.black54,
                                                        fontSize: 12.sp,
                                                        fontWeight:
                                                            FontWeight.w500),
                                                    maxLines: 1,
                                                  ),
                                                  SizedBox(
                                                    height: 0.4.h,
                                                  ),
                                                  Text(
                                                    text4[index],
                                                    style: TextStyle(
                                                        color: Colors.black54,
                                                        fontSize: 9.sp,
                                                        fontWeight:
                                                            FontWeight.w500),
                                                  ),
                                                  const Divider(
                                                      color: Colors.black12),
                                                  InkWell(
                                                    onTap: (){
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>  const ViewTariff()),
                                                      );
                                                    },
                                                    child: Text(
                                                      "View Tariff",
                                                      style: TextStyle(
                                                          color: const Color(
                                                              0xff3b7ad9),
                                                          fontSize: 10.sp,
                                                          fontWeight:
                                                              FontWeight.w500),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      }),
                                ),
                                SizedBox(
                                  height: 4.3.h,
                                ),
                                const Divider(color: Colors.black54),
                              ],
                            );
                          })),
                  height: 74.h,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(35),
                      topRight: Radius.circular(35),
                    ),
                    color: Colors.white,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 2.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.qr_code_scanner,
                      color: Colors.white,
                      size: 4.h,
                    ),
                    SizedBox(
                      width: 1.5.w,
                    ),
                    Text(
                      'Scan QRCode',
                      style: TextStyle(fontSize: 13.sp, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
